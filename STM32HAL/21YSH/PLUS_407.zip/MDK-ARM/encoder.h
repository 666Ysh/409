#ifndef  __encoder_H
#define  __encoder_H

#include "main.h"
#include "tim.h"

//void forward_ref(void);
//void back_ref(void);
//void left_ref(void);
//void right_ref(void);
//void stop_ref(void);

//void forward(void);
//void back(void);
//void left(void);
//void right(void);

#endif
