#include "encoder.h"
#include "usart.h"
#include "main.h"
#include "tim.h"
#include "gpio.h"
#include "pid.h"

//void forward_ref()		//��ǰ����ǰ��ǰ
//{
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1,2000);//��ǰ 
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3,2000);//��ǰ
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2,0); 
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_4,0); 
//}
//void back_ref()			//�������Һ�
//{
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3,0);//�Һ�
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1,0);
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2,1000);//���
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_4,1000);
//}
//void left_ref()			//��ת�������ǰ
//{
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_4,0);
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1,0);
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2,1000);
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3,1000);
//}
//void right_ref()		//��ת����ǰ�Һ�
//{
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2,0);
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3,0);
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1,1000);
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_4,1000);		
//}
//void stop_ref()			//ռ�ձȶ�Ϊ0
//{
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1,0);
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2,0);
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3,0);
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_4,0);
//}
