#ifndef  __motor_H
#define  __motor_H

#include "main.h"
#include "tim.h"

#define AIN1_SET HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_SET);
#define AIN1_RESET HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_RESET);
#define BIN1_SET HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_SET);
#define BIN1_RESET HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_RESET);

void Motor_Set(int motor1,int motor2);
void motorPidSetSpeed(float Motor1Speed,float Motor2Speed);
void forward(void);
void back(void);
void right(void);
void right_ref(void);
void left(void);
void left_ref(void);
void stop(void);
void motorPidSpeedUp(void);
void motorPidSpeedCut(void);
#endif
