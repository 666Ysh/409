#include "motor.h"
#include "usart.h"
#include "main.h"
#include "tim.h"
#include "gpio.h"
#include "pid.h"
#include "freertos.h"

#define MAX_SPEED_UP  40
#define MAX_SPEED_Cut 10

extern float Motor1Speed;
extern float Motor2Speed;
extern tPid pidMotor1Speed;
extern tPid pidMotor2Speed;

void Motor_Set(int motor1,int motor2)
{
	motor1=-motor1;
	motor2=-motor2;
	if(motor1 < 0) {AIN1_SET;}
		else  {AIN1_RESET;}
	if(motor2 < 0) {BIN1_RESET;}
		else  {BIN1_SET;}
		
	if(motor1<0)
	{
		if(motor1 < -99) motor1=-99	;
		__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_3,100+motor1);
	}
	else
	{
		if(motor1>99) motor1=99 ;
		__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_3,motor1);
	}	
		if(motor2<0)
	{
		if(motor2<-99) motor2=-99	;
//		__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_4,-motor2);
		__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_4,100+motor2);
	}
	else
	{
		if(motor2>99) motor2=99 ;
//		__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_4,100-motor2);
		__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_4,motor2);
	}	
}
void  motorPidSetSpeed(float Motor1Speed,float Motor2Speed)
{
	//����PIDĿ��ת��
	pidMotor1Speed.target_val = Motor1Speed;
	pidMotor2Speed.target_val = Motor2Speed;
	//PID������Ƶ��
	Motor_Set(PID_realize(&pidMotor1Speed,Motor1Speed),PID_realize(&pidMotor2Speed,Motor2Speed));
}
void forward(void)
{
	motorPidSetSpeed(10,10);//��ǰ
}
void back(void)
{
	motorPidSetSpeed(-10,-10);//���
}
void right(void)
{
	motorPidSetSpeed(10,5);//�ұ�
}
void right_ref(void)
{
	motorPidSetSpeed(10,-10);//��ת��
}
void left(void)
{
	motorPidSetSpeed(5,10);//���
}
void left_ref(void)
{
	motorPidSetSpeed(-10,10);//��ת��
}
void stop(void)
{
	motorPidSetSpeed(0,0);//ֹͣ
}
void motorPidSpeedUp(void)//����
{
	static float motorSpeedUp = 0.5;
	if(motorSpeedUp < MAX_SPEED_UP) motorSpeedUp +=0.1;
	motorPidSetSpeed(motorSpeedUp,motorSpeedUp);
}
void motorPidSpeedCut(void)//����
{
	static float motorSpeedCut = 30;
	if(motorSpeedCut > MAX_SPEED_Cut) motorSpeedCut -=2;
	motorPidSetSpeed(motorSpeedCut,motorSpeedCut);
}

